

// for single or double precision calculations
// do not forget to choose the proper kernel!
//#define SCALAR double
#define SCALAR float

extern int mat_vec_host(
  int kernel_index,
  SCALAR* a, 
  SCALAR* b, 
  SCALAR* result, 
  int width, 
  int height, 
  int nr_threads, 
  int work_group_size, 
  const cl_context context, 
  const cl_kernel kernel, 
  const cl_command_queue queue
			) ;


extern void mat_vec_test(
  const SCALAR* M, 
  uint width, 
  uint height, 
  const SCALAR* V, 
  SCALAR* W
		  ) ;

extern void print_execution_time(
			 int kernel_index,
			 double time,
			 int width,
			 int height
				 );

extern int verify_result(
  SCALAR* result,
  SCALAR* result_compare,
  int length
		  );
