#include<stdlib.h>
#include<stdio.h>
#include <math.h>

#include <CL/cl.h>

#include"OpenCL_util.h"

#include"mat_vec_host.h"

#define time_measurments

#ifdef time_measurments
#include"system_util.h"
  static double t_begin, t_end, t_total;
#endif


  /*----------------KERNEL CREATION PHASE----------------------*/
void create_kernels()
{

  // for all operations indicate explicit info messages
  int monitor = UTC_BASIC_INFO + 1;

  int kernel_index;
  
  // calculations are performed for the selected platform
  int platform_index = utv_ocl_struct.current_platform_index;
  
  if(utr_ocl_GPU_context_exists(platform_index)){

#ifdef time_measurments
  t_begin = time_clock();
#endif
  // create the first kernel for GPU
  kernel_index = 0; 
  utr_ocl_create_kernel_dev_type( platform_index, UTC_OCL_DEVICE_GPU, kernel_index,
				  // kernel name:         , file:
				  "mat_vec_1_kernel", "mat_vec_1.cl", monitor);
  
#ifdef time_measurments
  t_end = time_clock();
  printf("EXECUTION TIME: creating CPU kernel %d: %lf\n", kernel_index, t_end-t_begin);
#endif
  
#ifdef time_measurments
  t_begin = time_clock();
#endif
  // create the second kernel for GPU
  kernel_index = 1; 
  utr_ocl_create_kernel_dev_type( platform_index, UTC_OCL_DEVICE_GPU, kernel_index,
				  // kernel name:         , file:
				  "mat_vec_2_kernel", "mat_vec_2.cl", monitor);
  
#ifdef time_measurments
  t_end = time_clock();
  printf("EXECUTION TIME: creating CPU kernel %d: %lf\n", kernel_index, t_end-t_begin);
#endif
  
#ifdef time_measurments
  t_begin = time_clock();
#endif
  
  // create the third kernel for GPU
  kernel_index = 2; 
  utr_ocl_create_kernel_dev_type( platform_index, UTC_OCL_DEVICE_GPU, kernel_index,
				  // kernel name:         , file:
				  "mat_vec_3_mem_opt_kernel", "mat_vec_3_mem_opt.cl", monitor);
  
#ifdef time_measurments
  t_end = time_clock();
  printf("EXECUTION TIME: creating GPU kernel %d: %lf\n", kernel_index, t_end-t_begin);
#endif
  
#ifdef time_measurments
  t_begin = time_clock();
#endif
  
  // create the fourth kernel for GPU
  kernel_index = 3; 
  utr_ocl_create_kernel_dev_type( platform_index, UTC_OCL_DEVICE_GPU, kernel_index,
				  // kernel name:         , file:
				  "mat_vec_4_mem_opt_par_red_kernel", "mat_vec_4_mem_opt_par_red.cl", monitor);
  
#ifdef time_measurments
  t_end = time_clock();
  printf("EXECUTION TIME: creating GPU kernel %d: %lf\n", kernel_index, t_end-t_begin);
#endif
  
#ifdef time_measurments
  t_begin = time_clock();
#endif
  
  // create the fifth kernel for GPU
  kernel_index = 4; 
  utr_ocl_create_kernel_dev_type( platform_index, UTC_OCL_DEVICE_GPU, kernel_index,
				  // kernel name:         , file:
				  "mat_vec_5_mem_opt_par_red_opt_kernel", "mat_vec_5_mem_opt_par_red_opt.cl", monitor);
  
#ifdef time_measurments
  t_end = time_clock();
  printf("EXECUTION TIME: creating GPU kernel %d: %lf\n", kernel_index, t_end-t_begin);
#endif
  
#ifdef time_measurments
  t_begin = time_clock();
#endif
  
  // create the sixth kernel for GPU
  kernel_index = 5; 
  utr_ocl_create_kernel_dev_type( platform_index, UTC_OCL_DEVICE_GPU, kernel_index,
				  // kernel name:         , file:
				  "mat_vec_6_mem_opt_par_red_opt_warp_kernel", "mat_vec_6_mem_opt_par_red_opt_warp.cl", monitor);
  
#ifdef time_measurments
  t_end = time_clock();
  printf("EXECUTION TIME: creating GPU kernel %d: %lf\n", kernel_index, t_end-t_begin);
#endif

  }
  
}

  /*----------------EXECUTION PHASE----------------------*/
void execute_kernels()
{

  // for all operations indicate explicit info messages
  int monitor = UTC_BASIC_INFO + 1;

  // calculations are performed for the first platform (platform_index == 0)
  int platform_index = utv_ocl_struct.current_platform_index;
  utt_ocl_platform_struct platform_struct = utv_ocl_struct.list_of_platforms[platform_index];

  int kernel_index, nr_threads, work_group_size, nr_work_groups;
  int i,j;
  cl_kernel kernel;

  if(monitor>UTC_BASIC_INFO){
    printf("\n------------Starting execution phase----------------\n");
  }

  // get hardware characteristics to select good matrix shape
  // the set of device characteristics stored in data structure
  int device_index = 0; 
  utt_ocl_device_struct device_struct = 
    utv_ocl_struct.list_of_platforms[platform_index].list_of_devices[device_index];
  double global_mem_bytes = device_struct.global_mem_bytes;
  double global_max_alloc = device_struct.global_max_alloc;
  double local_mem_bytes = device_struct.local_mem_bytes;
  double constant_mem_bytes = device_struct.constant_mem_bytes;
  int max_num_comp_units = device_struct.max_num_comp_units;
  int max_work_group_size = device_struct.max_work_group_size;

  // choose the height of matrix
#define WORK_GROUP_SIZE 128
#define NR_WORK_GROUPS_DEFAULT 256
#define MULT_MAX 32
 // #define MULT_MAX 1
  int width = MULT_MAX*WORK_GROUP_SIZE ;

  // choose the width of matrix as big as possible (but as a multiple of 256)
  int height = global_max_alloc/sizeof(SCALAR)/(width+2);
  height = WORK_GROUP_SIZE*(height/WORK_GROUP_SIZE);

  if((height+1)*(width+1)*sizeof(SCALAR) > global_max_alloc){
    printf("Too large array: width %d, height %d, bytes %d. Exiting!\n",
	   width, height, (height+1)*(width+1)*sizeof(SCALAR));
    exit(0);
  }

  if(monitor>UTC_BASIC_INFO){
    printf("For device %d with %d comp_units, max_mem_alloc %lf\n",
	   device_index, max_num_comp_units, global_max_alloc);
    printf("Selected array parameters: width %d, height %d, bytes %d\n",
	   width, height, height*width*sizeof(SCALAR));
  } 

  // create standard (host) data structures
  // used to store the arguments to the kernel
  SCALAR *result;
  result = (SCALAR *)malloc(height*sizeof(SCALAR));
  SCALAR *result_compare;
  result_compare = (SCALAR *)malloc(height*sizeof(SCALAR));
  SCALAR *a;
  a = (SCALAR *)malloc(height*width*sizeof(SCALAR));
  SCALAR *b;
  b = (SCALAR *)malloc(width*sizeof(SCALAR));
  for (i = 0; i < height*width; i++)
    {
      a[i] = ((SCALAR)i)/10000.0;
    }
  for (i = 0; i < width; i++)
    {
      b[i] = ((SCALAR)(width-i))/100000.0;
    }
  

#ifdef time_measurments
  printf("\n------------Starting OpenMP execution phase----------------\n");
  t_begin = time_clock();
#endif

  // clear array of results
#pragma omp parallel for default(none) shared(height, result_compare) 
  for (i = 0; i < height; i++) result_compare[i]=0.0;

  // perform standard calculations
#pragma omp parallel for default(none) shared(height, width, a, b, result_compare) 
  for(i=0;i<height;i++){
    int j;
    for(j=0;j<width;j++){
      result_compare[i] += a[i*width+j] * b[j];
    }
  }

#ifdef time_measurments
  t_end = time_clock();
  printf("EXECUTION TIME: executing standard loop: %lf\n", t_end-t_begin);
  printf("\tNumber of operations %d, PERFORMANCE %lf GFlops\n",
	 2*width*height, 2*width*height / (t_end-t_begin) * 1e-9);
  printf("\tGBytes transferred to processor %lf - %lf, speed %lf - %lf GB/s\n",
	 width*height*sizeof(SCALAR)*1e-9, 2*width*height*sizeof(SCALAR)*1e-9, 
	 width*height*sizeof(SCALAR)/(t_end-t_begin)*1e-9,
	 2*width*height*sizeof(SCALAR)/(t_end-t_begin)*1e-9);
#endif

  for (i = 0; i < height; i++) result[i]=0.0;


  // test interface
  mat_vec_test(a, width, height, b, result);

  // verify result 
  verify_result(result, result_compare, height);
    

  // in a loop over devices (or for a selected device)
  int idev=0; 
  for(idev=0; idev<platform_struct.number_of_devices; idev++)
    {

    // int device_type = .....
    // choose device_index
    // int device_index = utr_ocl_select_device(platform_index, device_type);
    int device_index = idev;
    int device_type = utr_ocl_device_type(platform_index, device_index); 

    // to omit the second CPU or GPU
    if(device_index>0 && device_type==utr_ocl_device_type(platform_index, device_index-1)) break; 

    // to omit CPU
    if(device_type == UTC_OCL_DEVICE_CPU) break;

    // choose the context
    cl_context context = utr_ocl_select_context(platform_index, device_index);  

    // choose the command queue
    cl_command_queue command_queue = 
      utr_ocl_select_command_queue(platform_index, device_index);  

    if(monitor>UTC_BASIC_INFO){
      printf("\nExecution: \t0. restoring context and command queue for platform %d and device %d\n",
	     platform_index, device_index);
    }

    if(context == NULL || command_queue == NULL){ 

      printf("failed to restore context and command queue for platform %d, device %d\n", 
	     platform_index, device_index);
      printf("%lu %lu\n", context, command_queue);
    }

    // ---------- execution of a single kernel with data manipulation
    // choose the kernel
    kernel_index = 0;
    kernel = utr_ocl_select_kernel(platform_index, device_index, kernel_index);  

    nr_threads = height;
    work_group_size = WORK_GROUP_SIZE;

    for (i = 0; i < height; i++) result[i]=0.0;
    mat_vec_host(kernel_index, a, b, result, width, height, 
		 nr_threads, work_group_size,
		 context, kernel, command_queue);


    // verify result 
    verify_result(result, result_compare, height);

    // ---------- the end of: execution of a single kernel with data manipulation

    // ---------- execution of a single kernel with data manipulation
    // choose the kernel
    kernel_index = 1;
    kernel = utr_ocl_select_kernel(platform_index, device_index, kernel_index);  

    work_group_size = WORK_GROUP_SIZE;
    nr_work_groups = height;
    nr_threads = work_group_size*nr_work_groups;

    for (i = 0; i < height; i++) result[i]=0.0;
    mat_vec_host_2(kernel_index, a, b, result, width, height, 
		 nr_threads, work_group_size,
		 context, kernel, command_queue);


    // verify result 
    verify_result(result, result_compare, height);

    // ---------- the end of: execution of a single kernel with data manipulation


    // ---------- execution of a single kernel with data manipulation
    // choose the kernel
    kernel_index = 2;
    kernel = utr_ocl_select_kernel(platform_index, device_index, kernel_index);  

    work_group_size = WORK_GROUP_SIZE;
    nr_work_groups = NR_WORK_GROUPS_DEFAULT;
    //nr_rows_per_work_group = height / nr_work_groups;
    nr_threads = work_group_size*nr_work_groups;

    for (i = 0; i < height; i++) result[i]=0.0;
    mat_vec_host_2(kernel_index, a, b, result, width, height, 
		 nr_threads, work_group_size,
		 context, kernel, command_queue);


    // verify result 
    verify_result(result, result_compare, height);

    // ---------- the end of: execution of a single kernel with data manipulation


    // ---------- execution of a single kernel with data manipulation
    // choose the kernel
    kernel_index = 3;
    kernel = utr_ocl_select_kernel(platform_index, device_index, kernel_index);  

    work_group_size = WORK_GROUP_SIZE;
    nr_work_groups = NR_WORK_GROUPS_DEFAULT;
    //nr_rows_per_work_group = height / nr_work_groups;
    nr_threads = work_group_size*nr_work_groups;

    for (i = 0; i < height; i++) result[i]=0.0;
    mat_vec_host_2(kernel_index, a, b, result, width, height, 
		 nr_threads, work_group_size,
		 context, kernel, command_queue);


    // verify result 
    verify_result(result, result_compare, height);

    // ---------- the end of: execution of a single kernel with data manipulation
      
    
    // ---------- execution of a single kernel with data manipulation
    // choose the kernel
    kernel_index = 4;
    kernel = utr_ocl_select_kernel(platform_index, device_index, kernel_index);  

    work_group_size = WORK_GROUP_SIZE;
    nr_work_groups = NR_WORK_GROUPS_DEFAULT;
    //nr_rows_per_work_group = height / nr_work_groups;
    nr_threads = work_group_size*nr_work_groups;

    for (i = 0; i < height; i++) result[i]=0.0;
    mat_vec_host_2(kernel_index, a, b, result, width, height, 
		 nr_threads, work_group_size,
		 context, kernel, command_queue);


    // verify result 
    verify_result(result, result_compare, height);

    // ---------- the end of: execution of a single kernel with data manipulation
      
    
    // ---------- execution of a single kernel with data manipulation
    // choose the kernel
    kernel_index = 5;
    kernel = utr_ocl_select_kernel(platform_index, device_index, kernel_index);  

    work_group_size = WORK_GROUP_SIZE;
    nr_work_groups = NR_WORK_GROUPS_DEFAULT;
    //nr_rows_per_work_group = height / nr_work_groups;
    nr_threads = work_group_size*nr_work_groups;

    for (i = 0; i < height; i++) result[i]=0.0;
    mat_vec_host_2(kernel_index, a, b, result, width, height, 
		 nr_threads, work_group_size,
		 context, kernel, command_queue);


    // verify result 
    verify_result(result, result_compare, height);
    
    // ---------- the end of: execution of a single kernel with data manipulation
        
    
  } // the end of loop over devices
  
  return;
  
}



/**---------------------------------------------------------*/
int mat_vec_host(
		 int kernel_index,
		 SCALAR* a, 
		 SCALAR* b, 
		 SCALAR* result, 
		 int width, 
		 int height, 
		 int nr_threads, 
		 int work_group_size, 
		 const cl_context context, 
		 const cl_kernel kernel, 
		 const cl_command_queue command_queue
		 ) 
{ 
  
  int i, retval;
  double t_begin, t_end, time_internal;
  cl_event ndrEvt;
  
  printf("\n\n***--- Starting execution of matrix-vector product for size %dx%d (%d MB) ---***\n",
	 height, width, height*width*sizeof(SCALAR)/1024/1024);
  printf("*****------------- Kernel index %d, Nr_threads %d, Work_group_size %d ---------*****\n",
	 kernel_index, nr_threads, work_group_size);
  
  int nr_work_groups=nr_threads/work_group_size;
  
  // Create memory objects that will be used as arguments to kernel. 
  cl_mem M = 0;
  cl_mem V = 0;
  cl_mem W = 0;
  
  printf("\n\t\t1. creating memory objects\n");
  
#ifdef time_measurments
  t_begin = time_clock();
#endif
  
  M = clCreateBuffer(context, CL_MEM_READ_ONLY ,
		     sizeof(SCALAR) * width*height, NULL, NULL);
  V = clCreateBuffer(context, CL_MEM_READ_ONLY ,
		     sizeof(SCALAR) * width, NULL, NULL);
  W = clCreateBuffer(context, CL_MEM_READ_WRITE,
		     sizeof(SCALAR) * height, NULL, NULL);
  
  if (M == NULL || V == NULL || W == NULL){
    printf("Error creating memory objects.\n");
    return 0;
  }
  
#ifdef time_measurments
  t_end = time_clock();
  printf("EXECUTION TIME: creating memory objects: %lf\n", t_end-t_begin);
#endif
  
  printf("\n\t\t2. copying memory objects being input data\n");
  
#ifdef time_measurments
  clFinish(command_queue);
  t_begin = time_clock();
#endif
  retval = clEnqueueWriteBuffer( command_queue, M, CL_FALSE, 0, 
				 sizeof(SCALAR) * width*height, a, 0, NULL, NULL);
  
  retval = clEnqueueWriteBuffer( command_queue, V, CL_FALSE, 0, 
				 sizeof(SCALAR) * width, b, 0, NULL, NULL);
  
#ifdef time_measurments
  clFinish(command_queue);
  t_end = time_clock();
  printf("EXECUTION TIME: copying memory objects: %lf\n", t_end-t_begin);
  printf("\tsize of data %lf GB, TRANSFER RATE %lf GB/s\n", 
	 sizeof(SCALAR) * (width*height+width) * 1.e-9,
	 sizeof(SCALAR) * (width*height+width) * 1.e-9 / (t_end-t_begin));
#endif
  
  
  // Set the kernel arguments (result, a, b)
  retval = clSetKernelArg(kernel, 0, sizeof(cl_mem), &M);
  retval |= clSetKernelArg(kernel, 1, sizeof(uint), &width);
  retval |= clSetKernelArg(kernel, 2, sizeof(uint), &height);
  retval |= clSetKernelArg(kernel, 3, sizeof(cl_mem), &V);
  retval |= clSetKernelArg(kernel, 4, sizeof(cl_mem), &W);
  if (retval != CL_SUCCESS)
    {
      printf("Failed to Set the kernel arguments.\n");
      return;
    }
  
  
  printf("\n\t\t3. executing kernel %d\n", kernel_index);
  printf("\tNumber of threads %d, Number of work_groups %d, Work_group_size %d\n",
	 nr_threads, nr_threads/work_group_size, work_group_size);
  
  size_t globalWorkSize[1] = { nr_threads };
  size_t localWorkSize[1] = { work_group_size };
  cl_uint work_dim = 1;
  
  
#ifdef time_measurments
  clFinish(command_queue);
  t_begin = time_clock();
#endif
  
  // Queue the kernel up for execution across the array
  retval = clEnqueueNDRangeKernel(command_queue, kernel, work_dim, NULL,
				  globalWorkSize, localWorkSize,
				  0, NULL,  &ndrEvt);
#ifdef time_measurments
  clWaitForEvents(1, &ndrEvt);
  clFinish(command_queue);
  t_end = time_clock();
  time_internal = utr_ocl_calculate_execution_time(ndrEvt);
  print_execution_time(kernel_index, time_internal, width, height);
#endif
  
  if (retval != CL_SUCCESS)
    {
      printf("Failed to queue kernel for execution.\n");
      return;
    }
  
  printf("\n\t\t4. copying memory objects being output data\n");
  
#ifdef time_measurments_1
  clFinish(command_queue);
  t_begin = time_clock();
#endif
  
  for (i = 0; i < height; i++) result[i]=0.0;
  // Read the output buffer back to the Host
  retval = clEnqueueReadBuffer(command_queue, W, CL_TRUE,
			       0, height * sizeof(SCALAR), result,
			       0, NULL, NULL);
#ifdef time_measurments_1
  clFinish(command_queue);
  t_end = time_clock();
  printf("EXECUTION TIME: copying output memory objects: %lf\n", t_end-t_begin);
  printf("\tsize of data %lf GB, TRANSFER RATE %lf GB/s\n", 
	 sizeof(SCALAR) * height * 1.e-9,
	 sizeof(SCALAR) * height * 1.e-9 / (t_end-t_begin));
#endif
  if (retval != CL_SUCCESS)
    {
      printf("Failed to read result buffer.\n");
      return;
    }
  
  return(retval);
  
}



void print_execution_time(
			 int kernel_index,
			 double time,
			 int width,
			 int height
			 )
{
  printf("EXECUTION TIME: executing kernel %d: %lf\n", kernel_index, time);
  printf("\tNumber of operations %d, PERFORMANCE %lf GFlops\n",
	 2*width*height, 2*width*height / (time) * 1e-9);
  printf("\tGBytes transferred to processor %.4lf - %.4lf, speed %.4lf - %.4lf GB/s\n",
	 width*height*sizeof(SCALAR)*1e-9, 2*width*height*sizeof(SCALAR)*1e-9, 
	 width*height*sizeof(SCALAR)/(time)*1e-9,
	 2*width*height*sizeof(SCALAR)/(time)*1e-9);

  return;
}


void mat_vec_test(
  const SCALAR* M, 
  uint width, 
  uint height, 
  const SCALAR* V, 
  SCALAR* W
		  ) 
{ 
  uint y; uint x;
  for (y = 0; y < height; ++y) {
    const SCALAR* row = M + y * width;
    SCALAR dotProduct = 0;
    for (x = 0; x < width; ++x)
      dotProduct += row[x] * V[x];
    W[y] = dotProduct;
  }
}

int verify_result(
  SCALAR* result,
  SCALAR* result_compare,
  int length
		  )
{

  SCALAR tolerance;
  if(sizeof(SCALAR)==4) tolerance = 1.e-4;
  else tolerance = 1.e-9;

  // Verify the result
  int result_OK = 1;
  int i;
  for(i = 0; i < length; i++) {
    if(fabs(result[i] - result_compare[i])/fabs(result_compare[i])>tolerance) {
      printf("%d %16.8f %16.8f\n", i, result[i], result_compare[i]);
      result_OK = 0;
      break;
    }
  }
  printf("\n\t\t5. verifying results: ");
  if(result_OK) {
    printf("Output is correct\n");
  } else {
    printf("Output is incorrect\n");
    //for(i = 0; i < length; i++) {
    for(i = 0; i < 10; i++) {
      printf("%16.8f %16.8f\n", result[i], result_compare[i]);
    }
    exit(0);
  }
  
    /* for(i = 0; i < length; i++) { */
    /*   printf("%16.8f %16.8f\n", result[i], result_compare[i]); */
    /* } */

  return(result_OK);
}
