#include<stdlib.h>
#include<stdio.h>
#include <math.h>

#include <CL/cl.h>

#include"OpenCL_util.h"

#include"mat_vec_host.h"

#define time_measurments

#ifdef time_measurments
#include"system_util.h"
#endif

/**---------------------------------------------------------*/
void mat_vec_host_2(
		 int kernel_index,
		 SCALAR* a, 
		 SCALAR* b, 
		 SCALAR* result, 
		 int width, 
		 int height, 
		 int nr_threads, 
		 int work_group_size, 
		 const cl_context context, 
		 const cl_kernel kernel, 
		 const cl_command_queue command_queue
		 ) 
{ 
  
  int i, retval;
  double t_begin, t_end, time_internal;
  cl_event ndrEvt;
  
  printf("\n\n***--- Starting execution of matrix-vector product for size %dx%d (%d MB) ---***\n",
	 height, width, height*width*sizeof(SCALAR)/1024/1024);
  printf("*****------------- Kernel index %d, Nr_threads %d, Work_group_size %d ---------*****\n",
	 kernel_index, nr_threads, work_group_size);
  
  int nr_work_groups=nr_threads/work_group_size;
  
  // Create memory objects that will be used as arguments to kernel. 
  cl_mem M = 0;
  cl_mem V = 0;
  cl_mem W = 0;
  
  printf("\n\t\t1. creating memory objects\n");
  
#ifdef time_measurments
  t_begin = time_clock();
#endif
  
  M = clCreateBuffer(context, CL_MEM_READ_ONLY ,
		     sizeof(SCALAR) * width*height, NULL, NULL);
  V = clCreateBuffer(context, CL_MEM_READ_ONLY ,
		     sizeof(SCALAR) * width, NULL, NULL);
  W = clCreateBuffer(context, CL_MEM_READ_WRITE,
		     sizeof(SCALAR) * height, NULL, NULL);
  
  if (M == NULL || V == NULL || W == NULL){
    printf("Error creating memory objects.\n");
    exit(-1);
  }
  
#ifdef time_measurments
  t_end = time_clock();
  printf("EXECUTION TIME: creating memory objects: %lf\n", t_end-t_begin);
#endif
  
  printf("\n\t\t2. copying memory objects being input data\n");
  
#ifdef time_measurments
  clFinish(command_queue);
  t_begin = time_clock();
#endif
  retval = clEnqueueWriteBuffer( command_queue, M, CL_FALSE, 0, 
				 sizeof(SCALAR) * width*height, a, 0, NULL, NULL);
  
  retval = clEnqueueWriteBuffer( command_queue, V, CL_FALSE, 0, 
				 sizeof(SCALAR) * width, b, 0, NULL, NULL);
  
#ifdef time_measurments
  clFinish(command_queue);
  t_end = time_clock();
  printf("EXECUTION TIME: copying memory objects: %lf\n", t_end-t_begin);
  printf("\tsize of data %lf GB, TRANSFER RATE %lf GB/s\n", 
	 sizeof(SCALAR) * (width*height+width) * 1.e-9,
	 sizeof(SCALAR) * (width*height+width) * 1.e-9 / (t_end-t_begin));
#endif
  
  
  // Set the kernel arguments (result, a, b)
  retval = clSetKernelArg(kernel, 0, sizeof(cl_mem), &M);
  if (retval != CL_SUCCESS)
    {
      printf("Failed to Sssseeeeeeeeeeeeeeet the kernel arguments.\n");
      return;
    }
  retval |= clSetKernelArg(kernel, 1, sizeof(uint), &width);
  if (retval != CL_SUCCESS)
    {
      printf("Failed to Sssset the kernel arguments.\n");
      return;
    }
  retval |= clSetKernelArg(kernel, 2, sizeof(uint), &height);
  if (retval != CL_SUCCESS)
    {
      printf("Failed to Sssset the kernel arguments.\n");
      return;
    }
  retval |= clSetKernelArg(kernel, 3, sizeof(cl_mem), &V);
  if (retval != CL_SUCCESS)
    {
      printf("Failed to Sssset the kernel arguments.\n");
      return;
    }
  retval |= clSetKernelArg(kernel, 4, sizeof(cl_mem), &W);
  if (retval != CL_SUCCESS)
    {
      printf("Failed to Sssset the kernel arguments.\n");
      return;
    }
  const size_t workspace_size = work_group_size*sizeof(SCALAR);
  retval |= clSetKernelArg(kernel, 5, workspace_size, NULL);
  if (retval != CL_SUCCESS)
    {
      printf("Failed to Set the kernel arguments.\n");
      return;
    }
  
  printf("\n\t\t3. executing kernel %d\n", kernel_index);
  printf("\tNumber of threads %d, Number of work_groups %d, Work_group_size %d\n",
	 nr_threads, nr_threads/work_group_size, work_group_size);
  
  
  size_t globalWorkSize[1] = { nr_threads };
  size_t localWorkSize[1] = { work_group_size };
  cl_uint work_dim = 1;
  
  
  
#ifdef time_measurments
  clFinish(command_queue);
  t_begin = time_clock();
#endif
  
  // Queue the kernel up for execution across the array
  retval = clEnqueueNDRangeKernel(command_queue, kernel, work_dim, NULL,
				  globalWorkSize, localWorkSize,
				  0, NULL,  &ndrEvt);
#ifdef time_measurments
  clWaitForEvents(1, &ndrEvt);
  clFinish(command_queue);
  t_end = time_clock();
  time_internal = utr_ocl_calculate_execution_time(ndrEvt);
  print_execution_time(kernel_index, time_internal, width, height);
#endif
  
  if (retval != CL_SUCCESS)
    {
      printf("Failed to queue kernel for execution.\n");
      exit(-1);
    }
  
  printf("\n\t\t4. copying memory objects being output data\n");
  
#ifdef time_measurments_1
  clFinish(command_queue);
  t_begin = time_clock();
#endif
  
  for (i = 0; i < height; i++) result[i]=0.0;

  // Read the output buffer back to the Host
  retval = clEnqueueReadBuffer(command_queue, W, CL_TRUE,
			       0, height * sizeof(SCALAR), result,
			       0, NULL, NULL);

#ifdef time_measurments_1
  clFinish(command_queue);
  t_end = time_clock();
  printf("EXECUTION TIME: copying output memory objects: %lf\n", t_end-t_begin);
  printf("\tsize of data %lf GB, TRANSFER RATE %lf GB/s\n", 
	 sizeof(SCALAR) * height * 1.e-9,
	 sizeof(SCALAR) * height * 1.e-9 / (t_end-t_begin));
#endif

  if (retval != CL_SUCCESS)
    {
      printf("Failed to read result buffer.\n");
      exit(-1);
    }
  
  clReleaseMemObject(M);
  clReleaseMemObject(V);
  clReleaseMemObject(W);
  
  return;
  
}

